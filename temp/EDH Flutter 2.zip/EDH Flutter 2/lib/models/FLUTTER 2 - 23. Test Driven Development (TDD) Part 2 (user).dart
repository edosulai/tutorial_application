class User {
  int id;
  String name;

  User({this.id = 0, this.name = 'No Name'});
}
