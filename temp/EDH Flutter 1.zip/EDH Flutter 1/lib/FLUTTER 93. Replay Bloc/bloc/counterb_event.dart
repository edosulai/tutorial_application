part of 'counterb_bloc.dart';

abstract class CounterbEvent extends ReplayEvent {}

class Increment extends CounterbEvent {}
