part of 'counter_bloc.dart';

@immutable
class CounterState {
  int value;

  CounterState(this.value);
}
