import 'package:division/division.dart';
import 'package:flutter/material.dart';

ParentStyle parentStyle = ParentStyle()
  ..width(200)
  ..width(300)
  ..borderRadius(all: 10)
  ..margin(all: 10)
  ..elevation(3)
  ..background.color(Colors.pink);
