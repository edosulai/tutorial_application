
import 'package:flutter/material.dart';
import 'package:tutorial_application/views/FLUTTER%2025.%20Hero%20&%20ClipRRect%20Widget%20(main%20page).dart';

void main() {
  return runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MainPage(),
    );
  }
}
