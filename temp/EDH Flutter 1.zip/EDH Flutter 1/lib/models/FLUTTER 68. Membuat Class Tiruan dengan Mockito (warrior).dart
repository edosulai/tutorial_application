class Warrior {
  String name = "no name";

  void rest() {}

  Future<bool> training() async {
    return true;
  }
}
