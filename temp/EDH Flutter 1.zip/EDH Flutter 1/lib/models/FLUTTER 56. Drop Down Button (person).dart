class Person {
  String name;

  Person(this.name);
}
